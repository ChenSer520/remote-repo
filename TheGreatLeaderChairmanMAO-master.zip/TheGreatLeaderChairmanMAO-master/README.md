# 毛泽东选集
## 在线版
[毛泽东选集共五卷](https://www.marxists.org/chinese/maozedong/index.htm)
+ [第一卷](https://www.marxists.org/chinese/maozedong/index.htm#0) 第一次国内革命战争时期&第二次国内革命战争时期
+ [第二卷](https://www.marxists.org/chinese/maozedong/index.htm#2) 抗日战争时期（上）
+ [第三卷](https://www.marxists.org/chinese/maozedong/index.htm#3) 抗日战争时期（下）
+ [第四卷](https://www.marxists.org/chinese/maozedong/index.htm#4) 第三次国内革命战争时期
+ [第五卷](https://www.marxists.org/chinese/maozedong/index.htm#5) 社会主义革命和社会主义建设时期（一）

## PDF版
> 用作下载阅读